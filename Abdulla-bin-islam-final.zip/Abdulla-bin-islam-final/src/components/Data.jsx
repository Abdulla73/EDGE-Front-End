import { useRef, useState } from "react";


const data = () => {
    const [empname, new_emp] = useState();
    const [depertment, new_depertment] = useState('')
    const [salary, new_salary] = useState('')

    const add = async (e) => {
        e.preventDefault()
        const res = await fetch("http://localhost:3000//home/abdullah777/employee/create",
            {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ a_name: empname, a_depertment: depertment, a_salary: salary,}),
            })
        alert('Data Inserted Successfully')

    }

    let getdata = useRef()
    let showdata = useRef()

    const call = async ()=>{
        const user =  await fetch('http://localhost:3000//home/abdullah777/employee/all')
        getdata.current = await user.json();
        alert("Data Called")
    }

    const showid = async ()=>{ 
        const user_id = getRef.current
        showdata.current.innerText = (user_id.map(id=>id.id))
    }

    return (
        <div>
            <form onSubmit={add} >
                Employee Name: <input type="text" value={empname} onChange={(e) => new_emp(e.target.value)} />
                Depertment: <input type="text" value={depertment} onChange={(e) => new_depertment(e.target.value)} />
                Salary: <input type="text" value={salary} onChange={(e) => new_salary(e.target.value)} />
                <button type="submit">Add</button>
            </form>

            <button onClick={call}>Call</button>
            <button onClick={showid}>Show</button>

            <p ref={showdata}></p>
        </div>
    );
};

export default data;
