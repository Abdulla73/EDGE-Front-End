// src/App.jsx
import React from 'react';
//import HomePage from './pages/HomePage';
import HomePage from './pages/HomePage';


const App = () => {
  return (
    <div>
      <HomePage />
    </div>
  );
};

export default App;
